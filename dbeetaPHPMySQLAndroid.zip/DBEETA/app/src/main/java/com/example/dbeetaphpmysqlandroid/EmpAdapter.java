package com.example.dbeetaphpmysqlandroid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EmpAdapter extends RecyclerView.Adapter<EmpAdapter.EmpViewHolder> {

    List<Emp> empList;
    Context context;

    public EmpAdapter(Context context, List<Emp> emps){
        this.context=context;

        empList = emps;
    }


    @NonNull
    @Override
    public EmpViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.itemcard, parent, false);

        return new EmpViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EmpViewHolder holder, int position) {

        Emp emp = empList.get(position);

        holder.id.setText(emp.getId());
        holder.firstName.setText(emp.getFirstName());
        holder.lastName.setText(emp.getLastName());
        holder.dob.setText(emp.getDob());

        holder.employeeId.setText(emp.getEmployeeId());
        holder.position.setText(emp.getPosition());
        holder.salary.setText(emp.getSalary());
        holder.joinedDate.setText(emp.getJoinedDate());

    }

    @Override
    public int getItemCount() {
        return empList.size();
    }

    public class EmpViewHolder extends RecyclerView.ViewHolder{

        TextView id,firstName,lastName,dob, employeeId, position, salary, joinedDate;


        public EmpViewHolder(@NonNull View itemView) {
            super(itemView);

            id= itemView.findViewById(R.id.id);
            firstName= itemView.findViewById(R.id.firstName);
            lastName= itemView.findViewById(R.id.lastName);
            dob= itemView.findViewById(R.id.dob);

            employeeId =  itemView.findViewById(R.id.employeeId);
            position  =  itemView.findViewById(R.id.position);
            salary =  itemView.findViewById(R.id.salary);
            joinedDate =  itemView.findViewById(R.id.joinedDate);
        }
    }
}
