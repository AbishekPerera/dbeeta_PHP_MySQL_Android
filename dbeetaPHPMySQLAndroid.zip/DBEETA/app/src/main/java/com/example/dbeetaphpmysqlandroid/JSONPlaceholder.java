package com.example.dbeetaphpmysqlandroid;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface JSONPlaceholder {

    @GET("dbeeta_PHP_MySQL_Android")
    Call<List<Emp>> getEmp();
}
